%% Test_3DCD_FD.m
% Build a finite difference matrix and RHS, f, for a 3D
% singularly perturbed convection-diffusion problem
% - epsilon (u_xx + u_yy + u_zz)(x,y,z)
%  + a . grad(u)(x,y,z) + b u(x,y,z)
%    = f(x,y,z) on (0,1)^3=Omega 
% and u=0 at boundary of Omega
% Discretization: 
%   Lapacian: 7-point 2nd order central FD 
%    grad(u): 1st order upwinding 
%          u: 1-point central
% In this version
%  * a is cell array of constants
%  * b is a constant
%  * f is function handle
% Mesh: Shishkin or Uniform mesh (but works on arbitrary)
% June 2024. Niall Madden, Thai Anh Nhan
% See also ???.m and .m 

fprintf('\n\n-------------------------------------\n');
fprintf('    Solving a singularly perturbed     \n')
fprintf('   3D *convection*-diffusion problem       \n');

clear;
disp('---------');

%% Problem data
% Script defines a, alpha (lower bounds for a), b and f
Problem_Data_3DCD; 
d = length(a); % number of dimensions (but only works for d=3)
Epsilons = 10.^(0:-2:-6); % epsilon = Epsilons(e)

%% Mesh parameters N
Ns = 2.^(3:6); % Discretize with N=Ns(n) intervals in each direction.
C = 2; % Constant for S-mesh transition point 

Errors     = zeros(length(Epsilons),length(Ns));
BuildTimes = zeros(length(Epsilons),length(Ns));
SolveTimes = zeros(length(Epsilons),length(Ns));
%ConvertTimes=zeros(length(Ns),length(Epsilons));

e=0;
for epsilon=Epsilons
   e=e+1;
   n=0;
   for N=Ns
      n=n+1;
      x = cell(1,3); % cell array for storing meshes
      for k=1:d 
         if (a{k}>0)
            x{k} = Smesh(C, epsilon, alpha{k}, N, 1);
         else
            x{k} = Smesh(C, epsilon, alpha{k}, N, 0);
         end
      end

      % Build system matrix
      BuildStart=tic; % Count built time
      [A, B] = Build_3DCD_FD(epsilon, a, b, f, x);
      %[~,~,A1,B1] = Build_3DRD_FD(epsilon, X{1}, X{2}, X{3}, fold);
      BuildTimes(e, n) = toc(BuildStart);
    
      %% Convert A to *.mtx for STRUMPACK
      % tic;
      % filename='test3D_N5E0_U';
      % dm2hb([filename,'.rua'],A,[],'title','key', 'RUA', 14);
      % hb_to_mm_real([filename,'.rua'],[filename,'.mtx']);
      % CTimes = toc;
      % ConvertTimes(n, Epsiloni) = CTimes;
    
      SolveStart = tic;
      uN = A\B;
      SolveTimes(e,n) = toc(SolveStart);
      X = cell(1,3);
      [X{1},X{2},X{3}]=meshgrid(x{1}(2:end-1), x{2}(2:end-1), x{3}(2:end-1));
      X{1} = reshape( permute(X{1},[2,1,3]), [], 1);
      X{2} = reshape( permute(X{2},[2,1,3]), [], 1);
      X{3} = reshape( permute(X{3},[2,1,3]), [], 1);
      Errors(e,n) = norm( uN - U(X,epsilon),'inf');
      fprintf('eps=%6.1e, N=%4d, error=%8.3e, build=%6.3f(s), solve=%6.3f(s)\n', ...
         epsilon, N, Errors(e,n), BuildTimes(e,n), SolveTimes(e,n));
  end
end

% %% Uncomment the next bit if you'd like to see some 
% % plots of computed solutions
% U_full = zeros(N+1,N+1,N+1); % Insert boundary conditions
% U_full(2:N,2:N,2:N) = permute(reshape(uN,N-1,N-1,N-1),[2,1,3]);
% figure(1);  surf(x{2}, x{3}, squeeze(U_full(N/2,:,:))); title('u(.5,y,z)');
% figure(2);  surf(x{1}, x{3}, squeeze(U_full(:,N/2,:)))
% figure(3);  surf(x{1}, x{2}, squeeze(U_full(:,:,N/2)))
% 
% figure(10);  plot(x{1}, squeeze(U_full(:,N/2,N/2)),'-o',...,
%    x{2}, squeeze(U_full(N/2,:, N/2)),'--o',...
%    x{3}, squeeze(U_full(N/2,N/2,:)),'-.s', ...
%    'LineWidth',2, 'MarkerSize', 8);
% legend('u(x,.5,.5)','u(.5,y,.5)','u(.5,.5,z)' );

