function [A, B] = Build_3DCD_FD(epsilon, a, b, f, X)
% BUILD_3DCD_RD   Build a linear system for a FDM applied to 3D CD problem
% - epsilon (u_xx + u_yy + u_zz)(x,y,z)
%  + a.x*u_x + a.y*u_y + a.z*u_z 
%  + b*u(x,y,z)
%    = f(x,y,z) on (0,1)^3=Omega 
% and u=0 at boundary of Omega
% NM June 2024
% INPUTS:
%   epsilon (scalar)
%   a     (cell array of constants)
%   b     (constant}
%   f     (function handle)
%   X     (cell array of vectors of lenght Nx+1, Ny+1 and Nz+1)
% OUTPUTS
%   A ( NxN Matrix with N=(Nz+1)(Ny+1)(Nz+1) )
%   B ( N vector)
% [Add note later on how to map A\B to 3D array and back again]

d = length(X);
assert (d == length(a), "a and X mush be cell arrays of the same length")
N = {length(X{1})-1, length(X{2})-1, length(X{3})-1};

%% Build matrix for D2 (i.e., 2nd-order FD)
d2 = cell(1,3);
for k=1:d
   d2{k} = delta_1D(X{k});
end
D2 = kron3(speye(N{3}-1), speye(N{2}-1), d2{1}) + ...
   kron3(speye(N{3}-1), d2{2}, speye(N{1}-1)) + ...
   kron3(d2{3}, speye(N{2}-1), speye(N{1}-1));

% Up/downwinding for first-order derivatives
d1 = cell(1,3);
for k=1:d
   if (a{k} > 0)
      d1{k} = downwind_1D(X{k});
   else
      d1{k} = upwind_1D(X{k});
   end
end
D1 = ...
   kron3(speye(N{3}-1), speye(N{2}-1), a{1}*d1{1}) + ...
   kron3(speye(N{3}-1), a{2}*d1{2}, speye(N{1}-1)) + ...
   kron3(a{3}*d1{3}, speye(N{2}-1), speye(N{1}-1));

%% Zero order term (just identity)
D0 = speye(length(D1));

%% Assumble system
A = -epsilon*D2 + D1 + b*D0;

%% RHS: f is a function of X{1}, X{2}, X{3} and epsilon
%% Make grid and reshape to vector with lexiographical ordering
[x_grid,y_grid,z_grid]=meshgrid(X{1}(2:end-1), X{2}(2:end-1), X{3}(2:end-1)); 
X_grid = {reshape( permute(x_grid,[2,1,3]), [], 1),...
   reshape( permute(y_grid,[2,1,3]), [], 1),...
   reshape( permute(z_grid,[2,1,3]), [], 1)};
B = f(X_grid, epsilon);

%% NOTE: assuming zero Dirictlet boundary conditions
end

%% various functions that are reused alot
function D2=delta_1D(mesh_pts)
%    DELTA_1D    Make a 1D discrete Laplacian for the given mesh
N = length(mesh_pts)-1;
H = diff(mesh_pts);
Hbar=(mesh_pts(3:N+1) - mesh_pts(1:N-1))/2;
D2 = sparse(...
   [2:N-1,         1:N-1,                         1:N-2], ...
   [1:N-2,         1:N-1,                         2:N-1], ...
   [1./H(2:N-1)./Hbar(2:N-1); -(1./H(1:N-1) + 1./H(2:N))./Hbar; 1./H(2:N-1)./Hbar(1:N-2)]');
end

function D=upwind_1D(mesh_pts)
%    UPWIND_1D    Make a 1D 1st order upwind finite different operator
N = length(mesh_pts)-1;
H = diff(mesh_pts);
D = sparse(...
   [1:N-1,      1:N-2], ...
   [1:N-1,      2:N-1], ...
   [-1./H(2:N); 1./H(2:N-1)]', N-1, N-1);
end

function D1=downwind_1D(mesh_pts)
%    DOWNWIND_1D    Make a 1D downwind operator
N = length(mesh_pts)-1;
H = diff(mesh_pts);
D1 = sparse(...
   [2:N-1,        1:N-1], ...
   [1:N-2,        1:N-1], ...
   [-1./H(2:N-1); 1./H(1:N-1)]', N-1, N-1);
end

function A=kron3(a,b,c)
% KRON3  comput the Kroneker product of 3 matrices
% Kronecker product is associative, so this is the
% same as kron(kron(a,b),c)
A =  kron(a,kron(b,c));
end