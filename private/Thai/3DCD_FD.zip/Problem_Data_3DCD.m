%% Singularly Perturbed Test Problem
% Based on S. Franz, F. Liu, H-G. Roos, M. Stynes, and A. Zhou. 
% The combination technique for a two-dimensional convection-diffusion
% problem with exponential layers. Appl. Math., 54(3):203–223, 2009.

% PDE is
% -epsilon(u_xx + u_yy + u_zz)(x,y,z)
%  + a{1}u_x + a{2}u_y + a{3}u_z + b u(x,y,z)
%    = f(x,y,z) on (0,1)^3=Omega 
TestCase='3DCD' ;
a = {-2,-3,-4}; % convection coef. NONE SHOULD BE ZERO!!!!
alpha = {1.99, 2.99, 3.99}; % |a{i}|>alpha{1} Used for mesh.
b = 1; % reaction coef

u1 =  @(x,epsilon)(cos(pi*x/2).*(1-exp(-2*x/epsilon)));
u2 =  @(y,epsilon)(((1-y).^3).*(1-exp(-3*y/epsilon)));
u3 =  @(z,epsilon)0.5*(exp(1)-exp(z)).*(1-exp(-4*z/epsilon));

du1 = @(x,epsilon)(exp(-2*x/epsilon).*(2*cos(pi*x/2)/epsilon+pi*sin(pi*x/2)/2)-pi*sin(pi*x/2)/2);
du2 = @(y,epsilon)(3*exp(-3*y/epsilon).*((1-y).^3/epsilon+(1-y).^2)-3*(1-y).^2);
du3 = @(z,epsilon) exp(-4*z/epsilon).*(1/2*exp(z) + 2*(exp(1) - exp(z))/epsilon) - 1/2*exp(z);

d2u1 = @(x,epsilon)(exp(-2*x/epsilon).*(pi^2*cos(pi*x/2)/4-2*pi*sin(pi*x/2)/epsilon-4*cos(pi*x/2)/epsilon^2)-...
    pi^2*cos(pi*x/2)/4);
d2u2 = @(y,epsilon)(3*exp(-3*y/epsilon).*(-3*(1-y).^2/epsilon-2*(1-y)-3*(1-y).^3/epsilon^2-3*(1-y).^2/epsilon)+6*(1-y));
d2u3 = @(z,epsilon) exp(-4*z/epsilon).*(-8*exp(1)/epsilon^2 + 1/2*exp(z)*(1-4/epsilon)^2) ...
   - 1/2*exp(z);
 
u   =  @(x,y,z,epsilon)u1(x,epsilon).*u2(y,epsilon).*u3(z,epsilon);
ux  =  @(x,y,z,epsilon)du1(x,epsilon).*u2(y,epsilon).*u3(z,epsilon);
uy  =  @(x,y,z,epsilon)u1(x,epsilon).*du2(y,epsilon).*u3(z,epsilon);
uz  =  @(x,y,z,epsilon)u1(x,epsilon).*u2(y,epsilon).*du3(z,epsilon);
uxx =  @(x,y,z,epsilon)d2u1(x,epsilon).*u2(y,epsilon).*u3(z,epsilon);
uyy =  @(x,y,z,epsilon)u1(x,epsilon).*d2u2(y,epsilon).*u3(z,epsilon);
uzz =  @(x,y,z,epsilon)u1(x,epsilon).*u2(y,epsilon).*d2u3(z,epsilon);

fxyz = @(x,y,z,epsilon) (-epsilon.*(uxx(x,y,z,epsilon) + uyy(x,y,z,epsilon) + uzz(x,y,z,epsilon)) ...
   + a{1}*ux(x,y,z,epsilon) + a{2}*uy(x,y,z,epsilon) + a{3}*uz(x,y,z,epsilon) ...
   + b*u(x,y,z,epsilon));

U = @(X,epsilon)u(X{1},X{2},X{3},epsilon);
f = @(X,epsilon)fxyz(X{1}, X{2}, X{3}, epsilon);

