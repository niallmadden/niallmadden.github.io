function x = Smesh(C, epsilon, alpha, N, layer_location)
% SMESH : return a Shishkin mesh on [0,1] with N intervals and
% with transition point
% tau = min(1/2, C*epsilon/alpha*log(N))
% layer_location is 0 (layer to left) or 1 (layer to right)

tau = min(1/2, C*epsilon/alpha*log(N));
if (layer_location == 0)
   x1 = linspace(0,tau,N/2+1);
else % layer_location == 1
   x1 = linspace(0,1-tau,N/2+1);
end
x2 = linspace(x1(end),1, N/2+1);
x = [x1, x2(2:end)]';